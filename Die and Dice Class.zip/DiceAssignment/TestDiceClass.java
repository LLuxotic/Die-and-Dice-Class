/* File: TestDiceClass.java
 * ----------------------
 * Simple test of the Dice class.
 *
 */

import acm.program.*;

public class TestDiceClass extends ConsoleProgram {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	// Global program variables used in methods
	int sum = 0;

	public void run() {
		setFont("Courier-16");

	// Local variables
	int numSides, numRolls;
		
		// Start PART ONE
		Die firstDie = new Die(); // Creates die
		numRolls = readInt("Enter number of rolls : ");
		dieRollingSimulation(numRolls, firstDie); // Die is rolled y times.
		average(sum, numRolls); // Calculates average of roll simulation
		// End PART ONE

		println("");

		// Start PART TWO
		numSides = readInt("Enter number of sides : "); // Gets number of sides
		Die secondDie = new Die(numSides); // Creates x-sided die
		numRolls = readInt("Enter number of rolls : ");
		dieRollingSimulation(numRolls, secondDie); // Die is rolled y times.
		average(sum, numRolls); // Calculates average of roll simulation
		// End PART TWO

		println("");

		// Start PART THREE
		Dice firstDice = new Dice(); // Creates pair of dice
		numRolls = readInt("Enter number of rolls : ");
		diceRollingSimulation(numRolls, firstDice); // Dice is rolled y times.
		average(sum, numRolls); // Calculates average of roll simulation
		// End PART THREE

		println("");

		// Start PART FOUR
		numSides = readInt("Enter number of sides : "); // Gets number of sides
		numRolls = readInt("Enter number of rolls : "); 
		Dice secondDice = new Dice(numSides); // Creates pair of x-sided dice
		diceRollingSimulation(numRolls, secondDice); // Dice is rolled y times.
		average(sum, numRolls); // Calculates average of roll simulation
		// End PART FOUR



	}

	/*
	 * Simulates a virtual rolling of a die with any (x) number of sides for any (y) amount of times.
	 * The simulation calculates the total sum of the rolls and is stored in the global 'sum' variable.
	 */
	private void dieRollingSimulation(int numRolls, Die die) {
		sum = 0; // resets value of sum
		for (int i = 0; i < numRolls; i++) {
			die.roll();
			sum += die.getValue();
			println(die.toString()); // prints detail of the roll simulation
		}
	}
	
	/*
	 * Simulates a virtual rolling of a pair of dice with any (x) number of sides for any (y) amount of times.
	 * The simulation calculates the total sum of the rolls and is stored in the global 'sum' variable.
	 */
	private void diceRollingSimulation(int numRolls, Dice dice) {
		sum = 0; // resets value of sum
		for (int i = 0; i < numRolls; i++) {
			dice.roll();
			sum += dice.getSum();
			println(dice.toString()); // prints detail of the roll simulation
		}
	}
	
	/*
	 * Calculates the average ONLY after the simulation has occurred.
	 * The method uses the global variable 'sum' where the sum of the rolls are stored.
	 * The method also used the program variable 'numRolls' to calculate the average.
	 * sum / numRolls = average. ie., sum = 6, numRolls = 2
	 * average = 6 / 2 = 3
	 */
	private void average(int sum, int numRolls) {
		double average = (double) (sum) / numRolls;
		println("Average roll value : " + average);


	}

}
