public class Die {

	// Program variables
	public static int numSides, sideRolled;
	
	// Creates a six-sided die.
	public Die() {
		numSides = 6;
	}
	
	// Creates a x-sided die.
	public Die(int sides) {
		numSides = sides;
	}
	
	public void roll() {
		sideRolled = (int) (Math.random() * (numSides - 1) + 1); 
	}
	
	public int getValue() {
		return sideRolled;
	}
	
	public int getSides() {
		return numSides;
	}
	
	public String toString() {
		return "Die Class : " + numSides + " sided die has die value = " + sideRolled + ".";
	}

}
