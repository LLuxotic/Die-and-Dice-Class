
public class Dice {

	// Instance variables
	public int sumRolled;
	Die dieOne, dieTwo;
	
	// Program variables
	int numOne, numTwo;
	
	// Creates a pair of six-sided dice
	public Dice() {
		dieOne = new Die();
		dieTwo = new Die();
	}
	
	// Creates a pair of x-sided dice
	public Dice(int sides) {
		dieOne = new Die(sides);
		dieTwo = new Die(sides);
	}
	
	public void roll() {
		dieOne.roll();
		numOne = dieOne.getValue();
		dieTwo.roll();
		numTwo = dieTwo.getValue();
		
		sumRolled = numOne + numTwo;
	}
	
	public int getSum() {
		return sumRolled;
	}
	
	public String toString() {
		return "Dice Class : \n		" + dieOne.getSides() + " sided die has die value = " + numOne 
		+ "\n		" + dieTwo.getSides() + " sided die has die value = " + numTwo + "\n		dice total = " + sumRolled;
				
	}
	
	

}
